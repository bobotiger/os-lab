#ifndef LAB_COMMON_H
#define LAB_COMMON_H
#include <errno.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
/* pthread 接口直接返回错误码；检查其他 POSIX 接口失败时，调用者传入 errno。 */
static void check(int error) {
    if (error) { fprintf(stderr, "%s\n", strerror(error)); exit(EXIT_FAILURE); }
}
/* 把配置参数转换为整数，并同时检查格式、溢出和允许的范围。 */
static int number(const char *text, int low, int high) {
    char *end;
    errno = 0;
    /* strtol 用 end 指向未转换的字符，用 errno 报告溢出；两者都要检查。 */
    long value = strtol(text, &end, 10);
    if (errno || !*text || *end || value < low || value > high) {
        fprintf(stderr, "Invalid %s; allowed %d..%d\n", text, low, high);
        exit(EXIT_FAILURE);
    }
    return (int)value;
}
/* 以毫秒为单位等待；0 表示不额外等待，不保证其他线程不会被调度。 */
static void pause_ms(int ms) {
    if (!ms) return;
    struct timespec delay = {ms / 1000, (ms % 1000) * 1000000L};
    /* nanosleep 若被信号打断，delay 保存剩余时间，继续等待；其他错误直接报告。 */
    while (nanosleep(&delay, &delay) == -1) if (errno != EINTR) check(errno);
}
#endif
