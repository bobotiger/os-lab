#define _POSIX_C_SOURCE 200809L
#include "../common.h"
/* lock 保护任务数、统计计数和关闭状态；条件检查与取任务使用同一把锁。 */
static pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;
/* changed 用于任务发布或关闭时通知工作线程；通知本身不等于已有可领取的任务。 */
static pthread_cond_t changed = PTHREAD_COND_INITIALIZER;
/* ready 只用于启动同步：让主线程知道所有工作线程已经准备好。 */
static pthread_cond_t ready = PTHREAD_COND_INITIALIZER;
/* arrived 为就绪线程数；items 为待领任务数；taken、errors 为领取和空取次数；closed 为关闭标志；use_if 选择等待方式。 */
static int arrived, items, taken, errors, closed, use_if;

static void *consume(void *arg) {
    int id = *(int *)arg;
    /* 先持锁再检查或修改共享状态。 */
    check(pthread_mutex_lock(&lock));
    ++arrived;
    /* 通知主线程重新检查 arrived；若主线程尚未等待，也能通过计数判断准备情况。 */
    check(pthread_cond_signal(&ready));
    while (!items && !closed) {
        printf("worker=%d WAIT\n", id);
        /* 条件等待会原子地释放 lock 并进入等待；返回前重新取得 lock。返回不保证 items 大于 0。 */
        check(pthread_cond_wait(&changed, &lock));
        printf("worker=%d WAKE items=%d closed=%d\n", id, items, closed);
        /* if 模式在等待返回后直接尝试取任务；while 模式会回到循环条件，重新检查 items 和 closed。 */
        if (use_if) break;
    }
    /* 关闭后只退出，不再领任务，避免把清理阶段的唤醒当成正常处理。 */
    if (!closed) {
        if (items) {
            --items;
            ++taken;
            printf("worker=%d TAKE remaining=%d\n", id, items);
        } else {
            /* 只记录空取尝试，不访问不存在的任务，让实验能继续输出统计结果。 */
            ++errors;
            printf("worker=%d EMPTY_ATTEMPT\n", id);
        }
    }
    /* 完成操作后释放锁；其他线程才能继续检查队列。 */
    check(pthread_mutex_unlock(&lock));
    return NULL;
}
int main(int argc, char **argv) {
    if (argc != 7 || (strcmp(argv[4], "signal") && strcmp(argv[4], "broadcast")) ||
        (strcmp(argv[5], "if") && strcmp(argv[5], "while"))) {
        fputs("Usage: queue WORKERS JOBS EMPTY_NOTICE signal|broadcast if|while OBSERVE_MS\n", stderr);
        return 2;
    }
    int workers = number(argv[1], 1, 8), jobs = number(argv[2], 0, 8);
    int empty_notice = number(argv[3], 0, 1), observe = number(argv[6], 100, 2000);
    use_if = !strcmp(argv[5], "if");
    pthread_t threads[8];
    int ids[8];
    setvbuf(stdout, NULL, _IOLBF, 0);
    for (int i = 0; i < workers; ++i) {
        ids[i] = i + 1;
        /* 每个工作线程执行 consume，一次运行最多领取一项任务。 */
        check(pthread_create(&threads[i], NULL, consume, &ids[i]));
    }
    check(pthread_mutex_lock(&lock));
    /* 等待全部线程就绪。工作线程持锁报告就绪后，在 changed 上等待时才释放锁。 */
    while (arrived < workers) check(pthread_cond_wait(&ready, &lock));
    if (empty_notice) {
        puts("NOTICE with no jobs");
        /* 提前通知始终使用广播，此时还没有加入任务；用来观察空队列下被唤醒的行为。 */
        check(pthread_cond_broadcast(&changed));
        check(pthread_mutex_unlock(&lock));
        pause_ms(observe);
        check(pthread_mutex_lock(&lock));
    }
    /* 持锁一次性发布任务，随后发出通知；修改状态与通知配合使用。 */
    items = jobs;
    printf("PUBLISH jobs=%d notice=%s\n", jobs, argv[4]);
    /* signal 通知一个等待者，broadcast 通知所有等待者；醒来的线程仍需竞争同一把锁。 */
    if (!strcmp(argv[4], "signal")) check(pthread_cond_signal(&changed));
    else check(pthread_cond_broadcast(&changed));
    check(pthread_mutex_unlock(&lock));
    /* 给工作线程留出运行时间；这是有限的观察窗口，不是对所有调度情况的保证。 */
    pause_ms(observe);
    check(pthread_mutex_lock(&lock));
    printf("SNAPSHOT published=%d taken=%d queued=%d empty_attempts=%d\n", jobs, taken, items, errors);
    /* 先输出正常运行的统计结果，再设置关闭状态并广播，使剩余线程可以退出。 */
    closed = 1;
    puts("CLOSE observation finished");
    check(pthread_cond_broadcast(&changed));
    check(pthread_mutex_unlock(&lock));
    /* 等待所有工作线程结束后再退出进程。 */
    for (int i = 0; i < workers; ++i) check(pthread_join(threads[i], NULL));
    return 0;
}
