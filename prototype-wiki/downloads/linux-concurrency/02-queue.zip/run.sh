#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
if [[ $# -lt 1 ]]; then
    printf 'Usage: bash run.sh seats|queue|pool|events\n'
    exit 0
fi
lab=$1
shift
case "$lab" in
    seats)
        source ./01-seats/config.sh
        directory=01-seats
        if [[ $# -eq 0 ]]; then set -- "$SEATS" "$BUYERS" "$GAP_MS" "$ARRIVAL_MS" "$LOCK"; fi
        ;;
    queue)
        source ./02-queue/config.sh
        directory=02-queue
        if [[ $# -eq 0 ]]; then set -- "$WORKERS" "$JOBS" "$EMPTY_NOTICE" "$NOTICE" "$WAIT" "$OBSERVE_MS"; fi
        ;;
    pool)
        source ./03-pool/config.sh
        directory=03-pool
        if [[ $# -eq 0 ]]; then set -- "$CAPACITY" "$ROUNDS" "$CANCEL" "$WORK_MS" "$CLEANUP"; fi
        ;;
    events)
        source ./04-events/config.sh
        if [[ $# -eq 0 ]]; then set -- "$SLOW_SEND_MS" "$FAST_SEND_MS" "$SLOW_WORK_MS" "$IO" "$HANDLER"; fi
        timeout 15s python3 04-events/main.py "$@"
        exit
        ;;
    *)
        printf 'Unknown lab: %s\n' "$lab" >&2
        exit 2
        ;;
esac
build=$(mktemp -d)
trap 'rm -f -- "$build/lab"; rmdir -- "$build"' EXIT
cc -std=c11 -O2 -Wall -Wextra -Wpedantic -Werror -pthread "$directory/main.c" -o "$build/lab"
timeout 45s "$build/lab" "$@"
