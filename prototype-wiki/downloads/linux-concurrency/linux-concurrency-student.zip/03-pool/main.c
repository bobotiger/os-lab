#define _POSIX_C_SOURCE 200809L
#include "../common.h"
#include <semaphore.h>
/* permits 的计数表示当前可用许可数；成功申请减 1，归还加 1。 */
static sem_t permits;
/* lock 保护统计值和取消次序，避免输出与计数混乱；资源容量由信号量控制。 */
static pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;
/* occupied 保证本轮全部线程先尝试申请，再允许成功者执行后续等待与归还。 */
static pthread_barrier_t occupied;
/* admitted、rejected、cancellations 分别统计成功、失败和取消数；cancel_limit、work_ms 来自配置；repair 为 1 时选择已有的 return 分支。 */
static int admitted, rejected, cancellations, cancel_limit, work_ms, repair;
static void *request(void *arg) {
    int id = *(int *)arg;
    check(pthread_mutex_lock(&lock));
    /* sem_trywait 尝试立即取得许可：成功返回 0；没有许可时返回 -1 并设置 errno=EAGAIN，不会一直等待。 */
    int acquired = sem_trywait(&permits) == 0;
    if (!acquired && errno != EAGAIN) check(errno);
    int cancel = 0;
    if (acquired) {
        ++admitted;
        /* 按本轮成功申请的顺序，前 cancel_limit 个线程模拟取消；申请失败者不会取消。 */
        cancel = admitted <= cancel_limit;
        cancellations += cancel;
    } else ++rejected;
    printf("request=%d %s\n", id, acquired ? "ACQUIRE" : "EAGAIN");
    check(pthread_mutex_unlock(&lock));
    /* 在此集合，申请失败的线程也必须参加；特殊的 SERIAL_THREAD 返回值同样表示成功。 */
    int rc = pthread_barrier_wait(&occupied);
    if (rc != PTHREAD_BARRIER_SERIAL_THREAD) check(rc);
    if (acquired) {
        /* 模拟占用资源的时间；正常完成与取消任务的线程都会等待。 */
        pause_ms(work_ms);
        check(pthread_mutex_lock(&lock));
        printf("request=%d %s release=%s\n", id, cancel ? "CANCEL" : "FINISH",
               (!cancel || repair) ? "yes" : "no");
        /* sem_post 归还一个许可。leak 模式跳过取消分支的归还，return 模式在两条路径都归还。 */
        if ((!cancel || repair) && sem_post(&permits) == -1) check(errno);
        check(pthread_mutex_unlock(&lock));
    }
    return NULL;
}
/* 仅在没有工作线程继续操作信号量时统计。统计过程临时取得许可，随后完整放回。 */
static int available(void) {
    int count = 0;
    /* 连续申请，直到 EAGAIN，得到当前可用许可数；不是仍有线程运行时的并发快照。 */
    while (sem_trywait(&permits) == 0) ++count;
    if (errno != EAGAIN) check(errno);
    /* 把统计时临时取得的许可全部归还，测量本身不能消耗资源。 */
    for (int i = 0; i < count; ++i) if (sem_post(&permits) == -1) check(errno);
    return count;
}
int main(int argc, char **argv) {
    if (argc != 6 || (strcmp(argv[5], "leak") && strcmp(argv[5], "return"))) {
        fputs("Usage: pool CAPACITY ROUNDS CANCEL WORK_MS leak|return\n", stderr);
        return 2;
    }
    int capacity = number(argv[1], 1, 8), rounds = number(argv[2], 1, 8);
    cancel_limit = number(argv[3], 0, capacity);
    work_ms = number(argv[4], 0, 500);
    repair = !strcmp(argv[5], "return");
    /* sem_init 的 pshared=0 表示同一进程内线程共享，初始计数为 capacity。 */
    if (sem_init(&permits, 0, (unsigned)capacity) == -1) check(errno);
    /* 每轮始终创建 capacity 个线程，所以集合点的参与者数量固定为 capacity。 */
    check(pthread_barrier_init(&occupied, NULL, (unsigned)capacity));
    setvbuf(stdout, NULL, _IOLBF, 0);
    /* 信号量在循环外初始化，因此上一轮未归还的许可会影响下一轮。 */
    for (int round = 1; round <= rounds; ++round) {
        printf("ROUND %d start_available=%d\n", round, available());
        admitted = rejected = cancellations = 0;
        pthread_t threads[8];
        int ids[8];
        for (int i = 0; i < capacity; ++i) {
            ids[i] = i + 1;
            /* 每个新线程代表一个请求，执行一次申请；本轮开始前重置的只是统计值。 */
            check(pthread_create(&threads[i], NULL, request, &ids[i]));
        }
        /* 等全部请求线程结束后再统计，区分许可仍被占用与结束后未归还。 */
        for (int i = 0; i < capacity; ++i) check(pthread_join(threads[i], NULL));
        printf("END round=%d admitted=%d cancelled=%d rejected=%d available=%d\n",
               round, admitted, cancellations, rejected, available());
    }
    /* 线程全部结束后销毁同步对象，不能在仍有等待者时销毁。 */
    check(pthread_barrier_destroy(&occupied));
    /* 释放信号量的系统资源；下一次启动程序会重新初始化。 */
    if (sem_destroy(&permits) == -1) check(errno);
    return 0;
}
