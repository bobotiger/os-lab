#define _POSIX_C_SOURCE 200809L
#include <errno.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

/* lock 保护共享余票数；split 与 whole 使用同一把锁，但持锁范围不同。 */
static pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;
/* start 是线程集合点：所有买家准备好后才继续，避免创建时间差掩盖交错。 */
static pthread_barrier_t start;
/* origin 是计时起点；输出中的时间戳表示相对启动经过的毫秒数。 */
static struct timespec origin;
/* remaining 是共享余票；gap_ms 是查询后等待时间，arrival_ms 是到达间隔，whole 为加锁方式开关。 */
static int remaining, gap_ms, arrival_ms, whole;
/* issued[id] 记录该买家是否拿到票。每个线程只写自己的位置，主线程等待结束后汇总。 */
static int issued[16];

/* pthread 接口直接返回错误码；与返回 -1 后设置 errno 的接口不同。 */
static void check(int error)
{
    if (error) {
        fprintf(stderr, "%s\n", strerror(error));
        exit(EXIT_FAILURE);
    }
}

static int number(const char *text, int low, int high)
{
    char *end;
    errno = 0;
    /* 解析整数并检查格式与溢出，防止非法配置进入实验。 */
    long value = strtol(text, &end, 10);
    if (errno || *text == '\0' || *end != '\0' || value < low || value > high) {
        fprintf(stderr, "Invalid value %s; allowed %d..%d\n", text, low, high);
        exit(EXIT_FAILURE);
    }
    return (int)value;
}

static void pause_ms(int milliseconds)
{
    if (milliseconds == 0) return;
    struct timespec delay = {milliseconds / 1000, (milliseconds % 1000) * 1000000L};
    /* nanosleep 执行实际等待；被信号打断时按剩余时间继续等待。 */
    while (nanosleep(&delay, &delay) == -1) {
        if (errno != EINTR) check(errno);
    }
}

static double elapsed_ms(void)
{
    struct timespec now;
    /* 单调时钟用于计算时间间隔，不受系统日期调整影响。 */
    if (clock_gettime(CLOCK_MONOTONIC, &now) == -1) check(errno);
    return (now.tv_sec - origin.tv_sec) * 1000.0 + (now.tv_nsec - origin.tv_nsec) / 1000000.0;
}

static void *buy(void *arg)
{
    int id = *(int *)arg;
    /* 等待全部买家到达集合点；返回 PTHREAD_BARRIER_SERIAL_THREAD 也表示成功。 */
    int result = pthread_barrier_wait(&start);
    if (result != PTHREAD_BARRIER_SERIAL_THREAD) check(result);
    /* id 从 0 开始：第一个等待 0 个间隔，第二个等待 1 个间隔，以此类推。 */
    pause_ms(id * arrival_ms);
    /* 取得互斥锁后才能读取共享余票；如果锁已被占用，这里会等待。 */
    check(pthread_mutex_lock(&lock));
    /* seen 是这个线程读取到的局部副本；其他线程更新 remaining 不会同步更新 seen。 */
    int seen = remaining;
    printf("%8.1f ms  buyer=%d READ   seen=%d\n", elapsed_ms(), id + 1, seen);
    /* split 在查询后释放锁，允许其他线程在等待期间查询或出票；whole 保持持锁。 */
    if (!whole) check(pthread_mutex_unlock(&lock));

    /* 学生观察的间隔：已经查过余票，尚未出票。 */
    pause_ms(gap_ms);

    /* split 出票前重新取得锁，但仍使用先前的 seen；whole 从未释放这把锁。 */
    if (!whole) check(pthread_mutex_lock(&lock));
    if (seen > 0) {
        /* 按该买家先前读到的数量写回余票，观察它与实际出票总数是否一致。 */
        remaining = seen - 1;
        issued[id] = 1;
        printf("%8.1f ms  buyer=%d ISSUE  left=%d\n", elapsed_ms(), id + 1, remaining);
    } else {
        printf("%8.1f ms  buyer=%d REJECT left=%d\n", elapsed_ms(), id + 1, remaining);
    }
    /* 一次申请结束后释放锁，其他买家才能进入受保护的操作。 */
    check(pthread_mutex_unlock(&lock));
    return NULL;
}

int main(int argc, char **argv)
{
    if (argc != 6 || (strcmp(argv[5], "split") && strcmp(argv[5], "whole"))) {
        fprintf(stderr, "Usage: seats SEATS BUYERS GAP_MS ARRIVAL_MS split|whole\n");
        return EXIT_FAILURE;
    }
    int capacity = number(argv[1], 1, 16);
    int buyers = number(argv[2], 1, 16);
    remaining = capacity;
    gap_ms = number(argv[3], 0, 1000);
    arrival_ms = number(argv[4], 0, 1000);
    whole = strcmp(argv[5], "whole") == 0;
    /* 初始化集合点，参与者数量必须与创建的买家线程数相同。 */
    check(pthread_barrier_init(&start, NULL, (unsigned)buyers));
    if (clock_gettime(CLOCK_MONOTONIC, &origin) == -1) check(errno);
    /* 标准输出按行刷新，方便观察；打印本身也会影响调度和耗时。 */
    setvbuf(stdout, NULL, _IOLBF, 0);
    printf("seats=%d buyers=%d gap_ms=%d arrival_ms=%d lock=%s\n",
           capacity, buyers, gap_ms, arrival_ms, argv[5]);
    pthread_t threads[16];
    int ids[16];
    for (int i = 0; i < buyers; ++i) {
        ids[i] = i;
        /* 创建真实 POSIX 线程，运行 buy；ids 数组在所有线程结束前保持有效。 */
        check(pthread_create(&threads[i], NULL, buy, &ids[i]));
    }
    int sold = 0;
    for (int i = 0; i < buyers; ++i) {
        /* 等待指定买家线程结束，随后再读取它的出票记录。 */
        check(pthread_join(threads[i], NULL));
        sold += issued[i];
    }
    printf("SUMMARY capacity=%d issued=%d left=%d\n", capacity, sold, remaining);
    /* 所有线程都退出后，释放集合点所用资源。 */
    check(pthread_barrier_destroy(&start));
    return EXIT_SUCCESS;
}
