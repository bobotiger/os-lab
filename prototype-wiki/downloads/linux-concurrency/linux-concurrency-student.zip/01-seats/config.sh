# 修改数值后保存，再执行 bash run.sh。
SEATS=1
BUYERS=1
GAP_MS=0
ARRIVAL_MS=0
LOCK=split
