"""Real local sockets with independently scheduled sends and adjustable handlers."""
import argparse
from concurrent.futures import ThreadPoolExecutor
from contextlib import ExitStack
import select
import socket
from threading import Lock
from time import monotonic, sleep


def milliseconds(value):
    parsed = int(value)
    if not 0 <= parsed <= 2000:
        raise argparse.ArgumentTypeError("allowed range is 0..2000")
    return parsed


def run(args):
    # 单调时钟作为共同起点；slow 和 fast 的发送时间都相对于这个时刻。
    origin = monotonic()
    # 输出锁只保证一行信息完整打印，不用于保护接收或处理过程。
    log_lock = Lock()
    # 分别记录每条消息的实际发送计时时刻与处理完成时刻，用于计算总耗时。
    sent, finished = {}, {}

    def log(message):
        with log_lock:
            print(f"{(monotonic() - origin) * 1000:8.1f} ms  {message}", flush=True)

    # 统一管理套接字；正常结束或出现异常时都会关闭已经登记的连接。
    with ExitStack() as resources:
        # clients 保存接收端，writers 保存发送端；slow 和 fast 各使用一对独立套接字。
        clients, writers = {}, {}
        for name in ("slow", "fast"):
            # 创建本地双向套接字对，不需要网络地址或服务器；这里固定一端发送、一端接收。
            incoming, outgoing = socket.socketpair()
            resources.enter_context(incoming)
            resources.enter_context(outgoing)
            clients[name], writers[name] = incoming, outgoing

        def send():
            # 按预设时刻安排发送；这些时刻不是相邻消息之间的间隔。
            schedule = sorted(((args.slow_send, "slow"), (args.fast_send, "fast")))
            for offset, name in schedule:
                # 独立发送线程等待到预设时刻，调度可能造成推迟；不会等待接收线程完成处理。
                sleep(max(0, origin + offset / 1000 - monotonic()))
                sent[name] = monotonic()
                log(f"SEND {name}")
                # sendall 把一个字节交给套接字发送；发送完成不表示接收或处理已经完成。
                writers[name].sendall(b"x")

        def handle(name):
            log(f"HANDLER_START {name}")
            if name == "slow":
                # 只给 slow 加上等待，模拟可等待的慢处理，不代表 CPU 密集计算。
                sleep(args.slow_work / 1000)
            finished[name] = monotonic()
            log(f"HANDLER_END {name}")

        # 发送线程池只有一个线程；处理线程池最多两个线程。退出上下文时会等待已提交的任务结束。
        with ThreadPoolExecutor(max_workers=1) as sender, ThreadPoolExecutor(max_workers=2) as workers:
            # 提交发送任务，让消息可以在接收线程等待或处理期间独立到达。
            sending = sender.submit(send)
            # 保存处理任务的 Future，最后等待它们完成并检查异常。
            jobs = []

            def receive(name):
                # recv 读取一个字节。阻塞模式可能在这里等待；epoll 模式在收到可读事件后才调用。
                if clients[name].recv(1) != b"x":
                    raise ConnectionError("unexpected message")
                log(f"RECEIVE {name}")
                if args.handler == "worker":
                    # 把处理交给工作线程后立即返回接收循环，读取方式仍由 IO 选项决定。
                    jobs.append(workers.submit(handle, name))
                else:
                    # inline 在接收线程中直接处理；handle 返回前不能继续接收下一条消息。
                    handle(name)

            if args.io == "blocking":
                # 固定先读 slow 再读 fast；即使 fast 已经到达，也可能在等待 slow 时被耽搁。
                for name in ("slow", "fast"):
                    # 为阻塞读取设置 10 秒上限，防止实验因意外情况无限等待。
                    clients[name].settimeout(10)
                    log(f"WAIT_READ {name}")
                    receive(name)
            else:
                # 创建 Linux epoll 实例；Python 的这些方法封装了对应的内核接口。
                with select.epoll() as poller:
                    # 把文件描述符映射到消息名，记录还有哪些连接尚未读取。
                    pending = {}
                    for name, connection in clients.items():
                        # 将接收端设为非阻塞；不会因为一次无数据读取而无限等待。
                        connection.setblocking(False)
                        pending[connection.fileno()] = name
                        # 对应 epoll_ctl 的注册操作：关注该文件描述符的 EPOLLIN 可读事件。
                        poller.register(connection.fileno(), select.EPOLLIN)
                    while pending:
                        # 对应 epoll_wait：最多等待 10 秒，返回已就绪连接；不按 slow、fast 的固定顺序读。
                        events = poller.poll(10)
                        if not events:
                            raise TimeoutError("no readable connection")
                        for descriptor, _ in events:
                            name = pending.pop(descriptor)
                            # 每条连接只读取一条消息，读取前取消监听，防止重复处理同一连接。
                            poller.unregister(descriptor)
                            receive(name)
            # 等待发送任务完成并传播异常，确保发送时刻已记录。
            sending.result()
            for job in jobs:
                # 等待所有工作线程处理完毕后，再计算每条消息的总耗时。
                job.result()
    for name in ("slow", "fast"):
        print(f"SUMMARY name={name} latency_ms={(finished[name] - sent[name]) * 1000:.1f}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("slow_send", type=milliseconds)
    parser.add_argument("fast_send", type=milliseconds)
    parser.add_argument("slow_work", type=milliseconds)
    parser.add_argument("io", choices=("blocking", "epoll"))
    parser.add_argument("handler", choices=("inline", "worker"))
    run(parser.parse_args())
