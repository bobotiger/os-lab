Linux 并发机制验证实验

在 Ubuntu 或 WSL Ubuntu 中解压本包，打开终端并进入解压目录。
需要已有的 Bash、C 编译器和 Python 3。

四个实验的配置分别在
01-seats/config.sh
02-queue/config.sh
03-pool/config.sh
04-events/config.sh

用文本编辑器改参数并保存，在本目录运行对应命令。
bash run.sh seats
bash run.sh queue
bash run.sh pool
bash run.sh events

脚本每次读取当前配置，并按需编译源码。
每次运行从初始状态开始。pool 的 ROUNDS 会在同一次运行里连续多轮。
运行时请保留整个目录结构，三个 C 实验使用 -pthread 编译。
具体参数、实验目标和记录要求见同目录 Word 任务书。
